-- MySQL dump 10.15  Distrib 10.0.28-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.0.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `empid` varchar(10) CHARACTER SET latin1 NOT NULL,
  `empat` varchar(100) CHARACTER SET latin1 NOT NULL,
  `type` text CHARACTER SET latin1 NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phoneno` bigint(10) NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `TOE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ouid` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`empid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES ('EMG5188010','SHP290104030826','MANAGE','',9040470515,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1,'0104030826','CH362424120646'),('EOP9128010','SHP290104030826','OPERATE','',9040470515,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1,'0104030826','CH362424120646'),('EMG6376011','SHP170113030822','MANAGE','',9040470515,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1,'0113030822','CH362424120646'),('EOP6949011','SHP170113030822','OPERATE','',9040470515,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1,'0113030822','CH362424120646');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;

--
-- Table structure for table `price`
--

DROP TABLE IF EXISTS `price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price` (
  `PriceID` varchar(100) NOT NULL,
  `ShopId` varchar(100) CHARACTER SET ascii NOT NULL,
  `ProdID` varchar(100) CHARACTER SET ascii NOT NULL,
  `Price` double NOT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT '1',
  `Stock` tinyint(4) NOT NULL DEFAULT '1',
  `Toe` varchar(255) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`PriceID`),
  UNIQUE KEY `PriceID` (`PriceID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price`
--

/*!40000 ALTER TABLE `price` DISABLE KEYS */;
INSERT INTO `price` VALUES ('PRICE1352712946060623','spid','PR982946060623',25,1,1,'2946060623'),('PRICE384582914060638','spid','PR652914060638',32,1,1,'2914060638'),('PRICE4143562946060623','spid','PR642946060623',36,1,1,'2946060623'),('PRICE5432450338080750','spid','PR180338080750',26,1,1,'0338080750'),('PRICE7336340338080750','spid','PR40338080750',193.6,1,1,'0338080750'),('PRICE826842957060645','spid','PR642957060645',79,1,1,'2957060645'),('PRICE8634472914060638','spid','PR402914060638',19,1,1,'2914060638'),('PRICE8658210348080724','spid','PR580348080724',43.2,1,1,'0348080724'),('PRICE9784652957060645','spid','PR882957060645',35,1,1,'2957060645');
/*!40000 ALTER TABLE `price` ENABLE KEYS */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `ProdID` varchar(100) NOT NULL,
  `CategoryID` varchar(100) CHARACTER SET ascii NOT NULL,
  `Brand` varchar(100) CHARACTER SET ascii NOT NULL,
  `fullName` varchar(255) CHARACTER SET ascii NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `Toe` varchar(255) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`ProdID`),
  UNIQUE KEY `ProdID` (`ProdID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('PR180338080750','GnS_6_5','Best Price','Bansi Rava-500g',1,'0338080750'),('PR402914060638','BRF_4_1','Parle','Coconut Cookies-120gm',1,'2914060638'),('PR40338080750','BRF_16_4','Leher','Bikaneri Bhujia-1kg',1,'0338080750'),('PR580348080724','BRF_5_4','24 Organic','Corn Dhaliya-500g',1,'0348080724'),('PR642946060623','GnS_2_5','Kamal Brand','Dry Grapes-100g',1,'2946060623'),('PR642957060645','BRF_9_3','Dr.Oetker','Funfoods- Mayonnaise- Eggless Tandori-275g',1,'2957060645'),('PR652914060638','PEC_11_4','Old Spice','Shaving Cream-75gm',1,'2914060638'),('PR882957060645','GnS_3_4','Everest','Dry Mango-50g',1,'2957060645'),('PR982946060623','GnS_3_4','Sakthi','Curry Powder-50g',1,'2946060623');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;

--
-- Table structure for table `shopinfo`
--

DROP TABLE IF EXISTS `shopinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopinfo` (
  `shpid` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `panno` varchar(20) NOT NULL,
  `tinno` varchar(20) NOT NULL,
  `phoneno` bigint(10) NOT NULL,
  `category` text,
  `locid` varchar(20) NOT NULL,
  `shop_type` varchar(100) NOT NULL,
  `ouid` varchar(50) NOT NULL,
  `addr` text NOT NULL,
  `veriactive` tinyint(4) NOT NULL DEFAULT '0',
  `useractive` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`shpid`),
  UNIQUE KEY `tinno` (`tinno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopinfo`
--

/*!40000 ALTER TABLE `shopinfo` DISABLE KEYS */;
INSERT INTO `shopinfo` VALUES ('SHP290104030826','LazyLad','Abhishek Khuntia','GBGSA123','32158315475945',9040470515,NULL,'13.0826802/80.270718','indi','CH362424120646','Plot no.10, Lazy lad, Chennai',0,0),('SHP170113030822','Lazy lad','Abhishek Khuntia','HVGA1253','3254824689',9040470515,NULL,'13.0691501/80.237889','indi','CH362424120646','French load,chennai',0,0);
/*!40000 ALTER TABLE `shopinfo` ENABLE KEYS */;

--
-- Table structure for table `superm`
--

DROP TABLE IF EXISTS `superm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `superm` (
  `entid` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `panno` varchar(20) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `ouid` varchar(100) NOT NULL,
  `regi_mail` varchar(100) NOT NULL,
  `phoneno` bigint(10) NOT NULL,
  `regi_addr` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `superm`
--

/*!40000 ALTER TABLE `superm` DISABLE KEYS */;
INSERT INTO `superm` VALUES ('SUP960338120954','Suraj Kirani','fdgfdsgfs','Abhishek Khuntia','CH362424120646','suraj.sgrm@gmail.com',9040470515,'Q city Hyderabad'),('SUP450307080915','Macho','MACHO AMLAI','Abhishek Khuntia','CH362424120646','mali@gmail.com',9040470515,'AGA'),('SUP172924020752','Anna Chicken Shop','HJAHGHDS','Abhishek Khuntia','CH362424120646','abhishek.lhuitnoia@gmail.com',9040470515,'gyasfsdgghsd');
/*!40000 ALTER TABLE `superm` ENABLE KEYS */;

--
-- Table structure for table `userbasic`
--

DROP TABLE IF EXISTS `userbasic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userbasic` (
  `uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `acctype` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'DEF',
  `locid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locaddr` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userbasic`
--

/*!40000 ALTER TABLE `userbasic` DISABLE KEYS */;
INSERT INTO `userbasic` VALUES ('CH362424120646','Abhishek Khuntia','abhishek.pilu@gmail.com','DEF','17.4447918/78.34830979999992','IIIT, Gachibowli, Hyderabad, Telangana, India'),('CH382344110745','manoj','aj.manoj99@gmail.com','DEF','19.3149618/84.79409110000006','Berhampur, Odisha, India'),('CH322313120714','Nibedita','abhishek.khuntia93@gmail.com','DEF','13.0648085/80.20772999999997','SAF Games Village, Chennai, Tamil Nadu, India'),('CH492342120737','Nibedita Khuntia','nibedita.khuntia66@gmail.com','DEF','13.0648085/80.20772999999997','SAF Games Village, Chennai, Tamil Nadu, India'),('CH742310010755','Goutami Mohanty','business@shopnpick.in','DEF',NULL,NULL),('CH732306010757','priyadarshini pattnaik','jagadishmini@rediffmail.com','DEF',NULL,NULL);
/*!40000 ALTER TABLE `userbasic` ENABLE KEYS */;

--
-- Table structure for table `userpass`
--

DROP TABLE IF EXISTS `userpass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpass` (
  `uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phoneno` bigint(10) NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `phoneno` (`phoneno`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpass`
--

/*!40000 ALTER TABLE `userpass` DISABLE KEYS */;
INSERT INTO `userpass` VALUES ('CH362424120646',9040470515,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1),('CH382344110745',7064722512,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1),('CH322313120714',9840835949,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1),('CH492342120737',8939761949,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1),('CH742310010755',9938644127,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1),('CH732306010757',9444638040,'6968dd2a070b320ef48f3710ae5f0cb9fe5e8533',1);
/*!40000 ALTER TABLE `userpass` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-30 13:35:03
